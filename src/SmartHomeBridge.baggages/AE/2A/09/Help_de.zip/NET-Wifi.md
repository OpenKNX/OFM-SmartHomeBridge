### WLAN

Für eine Verbindung zum WLAN sind die SSID und das entsprechende Passwort erforderlich. Zusätzliche Einstellungen wie die Verschlüsselung können nicht angepasst werden und sind teilweise hardwareabhängig. Enterprise-Netzwerke, beispielsweise solche mit Zertifikaten, werden nicht unterstützt.

#### Ersteinrichtung

Die Ersteinrichtung variiert je nach Hardware bzw. Firmware. Möglicherweise muss die erste Verbindung zunächst über einen Hotspotmodus oder das virtuelle USB-Laufwerk eingerichtet werden. Geräte mit einem TP-Anschluss werden in der Regel darüber konfiguriert.