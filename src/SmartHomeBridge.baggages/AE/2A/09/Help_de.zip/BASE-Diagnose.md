### Diagnose

Das Diagnose-KO ermöglicht das Abfragen interner Zustände und das Auslösen bestimmter Funktionen. Der genaue Funktionsumfang variiert je nach der verwendeten Firmware und den darin enthaltenen Modulen.