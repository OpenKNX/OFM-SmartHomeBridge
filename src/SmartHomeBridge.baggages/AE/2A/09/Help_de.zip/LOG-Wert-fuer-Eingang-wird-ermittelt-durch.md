﻿### Wert für Eingang wird ermittelt durch

Mit dem Auswahlfeld wird der passende Zahlenkonverter ausgewählt.

