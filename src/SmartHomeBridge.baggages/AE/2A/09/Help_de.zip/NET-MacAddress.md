### MAC-Adresse

Die MAC-Adresse wird standardmäßig aus der Seriennummer abgeleitet (5E:84:XX:XX:XX:XX) und erfordert in der Regel keine Anpassung. Sollte jedoch eine individuelle Anpassung gewünscht sein, muss diese im Format XX:XX:XX:XX:XX:XX angegeben werden.