### Netzwerkadapter

Wähle hier aus, ob das verwendete Gerät über einen LAN- oder WLAN-Adapter verfügt.