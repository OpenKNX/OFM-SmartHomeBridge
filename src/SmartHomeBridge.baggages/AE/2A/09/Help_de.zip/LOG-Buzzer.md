﻿### Buzzer

Das Logikmodul unterstützt 3 verschiedene Töne bzw. Lautstärken für den Buzzer.
In den Eingabefeldern kann man die Tonfrequenzen für die einzelnen Töne für Laut/Mittel und Leise angeben. Über die Tonhöhe werden indirekt auch die Lautstärken gesteuert.

