﻿### Grad

In dieser Spalte wird der Sonnenwinkel über oder unter dem Horizont eingestellt als Winkel in Grad.

