﻿### Nummer des zusätzlichen KO

Hier wird die Nummer des Kommunikationsobjekts angegeben, über die der Wert zusätzlich gesendet werden soll. Das kann ein beliebiges KO (Eingang oder Ausgang) des Gerätes sein.

